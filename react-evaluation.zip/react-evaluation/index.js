const API = (() => {
  const URL = "http://localhost:3000";
  const getCart = () => {
    // define your method to get cart data
    return new Promise((resolve, reject) => {
      ajaxRequest('GET', `${URL}/cart`).then(resolve, reject)
    })
  };

  const getInventory = () => {
    // define your method to get inventory data
    return new Promise((resolve, reject) => {
      ajaxRequest('GET', `${URL}/inventory`).then(resolve, reject)
    })

  };

  const addToCart = (inventoryItem) => {
    // define your method to add an item to cart
    return new Promise((resolve, reject) => {
      ajaxRequest('POST', `${URL}/cart`, inventoryItem).then(resolve, reject)
    })
  };

  const updateCart = (id, newAmount) => {
    // define your method to update an item in cart
    return new Promise((resolve, reject) => {
      ajaxRequest('PATCH', `${URL}/cart/${id}`, {
        num: newAmount
      }).then(resolve, reject)
    })
  };

  const deleteFromCart = (id) => {
    // define your method to delete an item in cart
    return new Promise((resolve, reject) => {
      ajaxRequest('Delete', `${URL}/cart/${id}`).then(resolve, reject)
    })

  };

  const checkout = () => {
    // you don't need to add anything here
    return getCart().then((data) =>
      Promise.all(data.map((item) => deleteFromCart(item.id)))
    );
  };

  return {
    getCart,
    updateCart,
    getInventory,
    addToCart,
    deleteFromCart,
    checkout,
  };
})();

const Model = (() => {
  // implement your logic for Model
  class State {
    #onChange;
    #inventory;
    #cart;
    constructor() {
      this.#inventory = [];
      this.#cart = [];
      this.queueList = []
    }
    get cart() {
      return this.#cart;
    }

    get inventory() {
      return this.#inventory;
    }

    set cart(newCart) {
      this.#cart = newCart;
      this.queueList.forEach(fn => fn())
    }
    set inventory(newInventory) {
      this.#inventory = newInventory
      this.queueList.forEach(fn => fn())
    }

    subscribe(cb) {
      this.queueList.push(cb)
    }
  }
  const {
    getCart,
    updateCart,
    getInventory,
    addToCart,
    deleteFromCart,
    checkout,
  } = API;
  return {
    State,
    getCart,
    updateCart,
    getInventory,
    addToCart,
    deleteFromCart,
    checkout,
  };
})();

const View = (() => {
  // implement your logic for View
  const inventoryEl = document.getElementsByClassName('inventory-ul')[0]
  const cartEl = document.getElementsByClassName('cart-ul')[0]
  const insertInventoryDom = (list) => {
    inventoryEl.innerHTML = ''
    const documentFragment = document.createDocumentFragment();
    for (let i = 0; i < list.length; i++) {
      const liEL = createInventoryLiEL(list[i].num, list[i].id, list[i].content)
      documentFragment.appendChild(liEL)
    }

    inventoryEl.appendChild(documentFragment)


  }
  const createInventoryLiEL = (num = 0, id, content) => {
    const liEL = document.createElement('li');
    const innerHtml = `
    <span>${content}</span>

    <span data-id='${id}' class="deleIcon"> - </span>
        <span >${num}</span>
        <span data-id='${id}' class="addIcon">+</span>
        <span data-id='${id}' class="addCart">add to cart</span>

  </li>
    `
    liEL.innerHTML = innerHtml
    return liEL
  }

  const insertCartDom = (list) => {
    cartEl.innerHTML = ''
    const documentFragment = document.createDocumentFragment();
    for (let i = 0; i < list.length; i++) {
      const liEL = createCartLiEL(list[i].num, list[i].id, list[i].content)
      documentFragment.appendChild(liEL)
    }

    cartEl.appendChild(documentFragment)
  }
  const createCartLiEL = (num = 0, id, content) => {
    const liEL = document.createElement('li');
    const innerHtml = `
    <span>${content} X ${num}</span>
        <span data-id='${id}' class="addCart">delete</span>

  </li>
    `
    liEL.innerHTML = innerHtml
    return liEL
  }

  return {
    insertInventoryDom,
    inventoryEl,
    insertCartDom,
    cartEl
  };
})();

const Controller = ((model, view) => {
  // implement your logic for Controller
  const state = new model.State();
  const { insertInventoryDom, inventoryEl, insertCartDom, cartEl } = view
  const { getCart,
    updateCart,
    getInventory,
    addToCart,
    deleteFromCart,
    checkout } = model

  const subscribeInventory = () => {
    insertInventoryDom(state.inventory)
  }
  const subscribeCard = () => {
    insertCartDom(state.cart)
  }
  const init = () => {

    state.subscribe(subscribeInventory)
    state.subscribe(subscribeCard)
    getInventory().then(res => {

      state.inventory = res

    })

    // getCart
    getCartList()
  };
  
  const getCartList = () => {
    getCart().then(res => {
      state.cart = res

    })
  }
  const handleUpdateAmount = () => {
    inventoryEl.addEventListener('click', (e) => {
      const { className, dataset } = e.target
      if (className === 'addIcon') {
        const arr = state.inventory.map(item => {

          if (item.id == dataset.id) {
            return {
              ...item,
              num: (item.num || 0) + 1
            }
          }
          return item
        })
        console.log(arr);
        state.inventory = arr
       
      }

      if (className === 'deleIcon') {
        const arr = state.inventory.map(item => {

          if (item.id == dataset.id) {
            return {
              ...item,
              num: item.num ? item.num - 1 : 0
            }
          }
          return item
        })
        console.log(arr);
        state.inventory = arr
      
      }

    })
  };

  const handleAddToCart = () => {
    inventoryEl.addEventListener('click', (e) => {
      const { className, dataset } = e.target
      if (className === 'addCart') {
        const inventoryItem = state.inventory.find(item => item.id == dataset.id)

        const cartItem = state.cart.find(item => item.id == dataset.id)

        if (inventoryItem.num) {

          if (inventoryItem && cartItem) {
            updateCart(inventoryItem.id, cartItem.num + inventoryItem.num).then(() => {
              getCartList()
            })

          }

          if (inventoryItem && !cartItem) {
            addToCart(inventoryItem).then(() => {
              getCartList()
            });
          }
        }

      }
    })
  };

  const handleDelete = () => {
    cartEl.addEventListener('click', (e) => {
      const { className, dataset } = e.target
      if (className === 'addCart') {
        deleteFromCart(dataset.id).then(() => {
          console.log('pppp');
          getCartList()
        })
      }
    })
  };

  const handleCheckout = () => {
    document.getElementsByClassName('checkout-btn')[0].addEventListener('click', (e) => {
      checkout().then(() => {
        state.cart = []
      })
    })
  };
  const bootstrap = () => {
    init()
    handleUpdateAmount()
    handleAddToCart()
    handleDelete()
    handleCheckout()
  };
  return {
    bootstrap,
  };
})(Model, View);

Controller.bootstrap();

function ajaxRequest(method, url, data = null) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();


    xhr.open(method, url, true);


    if (method === 'POST' || method === 'PUT' || method === 'PATCH') {
      xhr.setRequestHeader('Content-Type', 'application/json');


      xhr.send(JSON.stringify(data));
    } else if (method === 'DELETE') {

      xhr.send();
    } else {

      xhr.send();
    }


    xhr.onreadystatechange = function () {
      if (xhr.readyState === 4) {
        if (xhr.status >= 200 && xhr.status < 300) {

          let response;
          try {
            response = JSON.parse(xhr.responseText);

          } catch (e) {

            response = xhr.responseText;
          }
          resolve(response);

        } else {

          // errorCallback(); 
          reject(xhr.status, xhr.responseText)
        }
      }
    };


    xhr.onerror = function () {
      reject(xhr.status, 'Network Error')
    };
  })

}  