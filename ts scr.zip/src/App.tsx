import React from 'react';
import SearchBar from './components/SearchBar';
import SearchResults from './components/SearchResults';
import Wishlist from './components/Wishlist';
import './App.css'; // Import your styles

const App: React.FC = () => {
  return (
    <div className="app-container">
      <h1>Book Search App</h1>
      <SearchBar />
      <SearchResults />
      <Wishlist />
    </div>
  );
};

export default App;
