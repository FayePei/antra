import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { removeFromWishlist } from '../redux/slices/wishlistSlice';
import { RootState } from '../redux/store';

const Wishlist: React.FC = () => {
  const wishlist = useSelector((state: RootState) => state.wishlist);
  const dispatch = useDispatch();

  return (
    <div className="wishlist">
      <h2>Wishlist</h2>
      {wishlist.length === 0 ? (
        <p>No books in the wishlist yet.</p>
      ) : (
        <ul>
          {wishlist.map((book) => (
            <li key={book.id}>
              <span>{book.volumeInfo.title}</span>
              <button onClick={() => dispatch(removeFromWishlist(book.id))}>
                Delete
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default Wishlist;
