import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { fetchBooks } from '../redux/slices/booksSlice';


const SearchBar: React.FC = () => {
  const [query, setQuery] = useState('');
  const dispatch = useDispatch();

  const handleSearch = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (query) {
      dispatch(fetchBooks(query));
    }
  };

  return (
    <form onSubmit={handleSearch}>
      <input 
        type="text" 
        value={query} 
        onChange={(e) => setQuery(e.target.value)} 
        placeholder="Search for books..."
      />
      <button type="submit">Search</button>
    </form>
  );
};

export default SearchBar;
