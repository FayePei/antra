import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { addToWishlist } from '../redux/slices/wishlistSlice';
import { RootState } from '../redux/store';

const SearchResults: React.FC = () => {
  const dispatch = useDispatch();
  const { items, status, error } = useSelector((state: RootState) => state.books);

  if (status === 'loading') {
    return <div>Loading...</div>;
  }

  if (status === 'failed') {
    return <div>Error: {error}</div>;
  }

  return (
    <div className="search-results">
      {items.map((book) => (
        <div key={book.id} className="book-card">
          <img 
            src={book.volumeInfo.imageLinks?.thumbnail || 'placeholder.jpg'} 
            alt={book.volumeInfo.title} 
          />
          <h3>{book.volumeInfo.title}</h3>
          <p><strong>Author(s):</strong> {book.volumeInfo.authors?.join(', ')}</p>
          <p><strong>Publisher:</strong> {book.volumeInfo.publisher}</p>
          <p><strong>Published Date:</strong> {book.volumeInfo.publishedDate}</p>
          <p>{book.volumeInfo.description}</p>
          <button onClick={() => dispatch(addToWishlist(book))}>
            Add to Wishlist
          </button>
        </div>
      ))}
    </div>
  );
};

export default SearchResults;
